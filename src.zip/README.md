# sca-lab

Static Code Analysis in CI/CD Pipeline Lab Resources
