const config = {
  port: process.env.PORT || 80
}

export default config
